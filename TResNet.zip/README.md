This version is still under construction.
The project requires:
Python3
Tensorflow 1.5+
numpy/scipy/sklearn
matplotlib

