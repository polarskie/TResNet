# import test
# import multiprocessing as mp
import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt
from flip_gradient import flip_gradient


if __name__ == "__main__":
    a = [[0.0, 0.0, 0.0],
         [1.0, 0.0, 0.0]]
    b = [[1.0, 0.0, 0.0],
         [1.0, 0.2, 0.4]]
    b_softmax = np.exp(b) / np.expand_dims(np.sum(np.exp(b), axis=1), axis=1)
    print(b_softmax)
    print(-np.sum(a * np.log(b_softmax), axis=1))
    tf_a = tf.constant(a)
    tf_b = tf.constant(b)
    sess = tf.Session()
    print(sess.run(tf.nn.softmax_cross_entropy_with_logits(labels=tf_a, logits=tf_b)))
    print(sess.run(tf.log(tf.constant(1.0)) / 0.0))
    zero = tf.constant(0, dtype=tf.float32)
    x = tf.constant([[1, 0], [1, 0], [0, 1], [1, 0]], dtype=tf.float32)
    where = tf.not_equal(x, zero)
    print(sess.run(tf.slice(tf.where(where), begin=(0, 1), size=(-1, -1))))
    v = tf.Variable([1.0, 2.0], dtype=tf.float32)
    loss = flip_gradient(tf.reduce_sum(v))
    op = tf.train.GradientDescentOptimizer(learning_rate=0.1).minimize(loss)
    sess.run(tf.global_variables_initializer())
    sess.run(op)
    print(sess.run(v))
