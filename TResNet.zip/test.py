from multiprocessing import Pool
import time


x, y = {'x': 12, 'y':34}
print(x)
print(y)
