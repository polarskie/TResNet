import TResNet
import pickle
import numpy as np
import time
from multiprocessing import Pool


def run_bias_only(args):
    X, D, Y, vX, vD, vY, lr, lbda, alpha, lN, id = args
    tres = TResNet.TResNetRegressProto(X.shape[1], D.shape[1], label_size=Y.shape[1], lbda=lbda, lr=lr, alpha=alpha,
                                       lN=lN, id=id)
    # tres = TResNet.TResNetRegressFC(X.shape[1], D.shape[1], label_size=Y.shape[1], lbda=lbda, lr=lr, alpha=alpha, lN=1)
    # tres = TResNet.TResNetRegressPC(X.shape[1], D.shape[1], label_size=Y.shape[1], lbda=lbda, lr=lr, alpha=alpha, lN=1)
    return tres.fit(X, D, Y, vX, vD, vY)


def run(args):
    X, D, Y, vX, vD, vY, lr, lbda, alpha, lN, id = args
    # tres = TResNet.TResNetRegressProto(X.shape[1], D.shape[1], label_size=Y.shape[1], lbda=lbda, lr=lr, alpha=alpha,
    #                                    lN=1)
    # tres = TResNet.TResNetRegressFC(X.shape[1], D.shape[1], label_size=Y.shape[1], lbda=lbda, lr=lr, alpha=alpha, lN=1)
    tres = TResNet.TResNetRegressPC(X.shape[1], D.shape[1], label_size=Y.shape[1], lbda=lbda, lr=lr, alpha=alpha, lN=1)
    return tres.fit(X, D, Y, vX, vD, vY)


def normalize(x):
    x = x - np.mean(x, axis=0)
    x = x / np.std(x, axis=0)
    return x


if __name__ == "__main__":
    with open('datasets/vigilance/vigilance_dataset.pkl', 'rb') as f:
        p = pickle.load(f)
    features = p['features']
    features = np.array([normalize(fea) for fea in features])
    labels = np.expand_dims(p['labels'], axis=-1)
    domains = [np.concatenate((np.zeros((features[i].shape[0], i), dtype=float),
                               np.ones((features[i].shape[0], 1), dtype=float),
                               np.zeros((features[i].shape[0], features.shape[0] - i - 1))), axis=1)
               for i in range(len(features))]

    X = np.concatenate(features, axis=0)
    D = np.concatenate(domains, axis=0)
    para_space = [np.power(2., np.arange(0, 1)) * 1e-5,
                  [0.5],
                  [0.],
                  [1]]

    for para_i in range(1):
        np.random.seed(int(time.time()))
        lr, lbda, alpha, lN = [p[int(np.random.rand() * len(p))] for p in para_space]
        print("********session %i*********\n"
              "running with hyper-parameters:\n"
              "lr\t\t%f\nlambda\t\t%f\nalpha\t\t%f\nlN\t\t%i\n" % (para_i, lr, lbda, alpha, lN))
        # run([X,
        #        D,
        #        np.concatenate([(labels[i]
        #                         if i != 0
        #                         else np.zeros(labels[i].shape, dtype=float) - 1.)
        #                        for i in range(len(labels))]),
        #        features[0],
        #        domains[0],
        #        labels[0],
        #        lr,
        #        lbda,
        #        alpha])
        p = Pool(2)
        r = p.map(run_bias_only, [[X,
                                   D,
                                   np.concatenate([(labels[i]
                                                    if i != target_domain_i
                                                    else np.zeros(labels[i].shape, dtype=float) - 1.)
                                                   for i in range(len(labels))]),
                                   features[target_domain_i],
                                   domains[target_domain_i],
                                   labels[target_domain_i],
                                   lr,
                                   lbda,
                                   alpha,
                                   lN,
                                   target_domain_i] for target_domain_i in range(23)])
        p.close()
        with open("./datasets/vigilance/results/log_" + str(lr) + '_' + str(lbda) + ".pkl", 'wb') as f:
            pickle.dump(r, f)

#
# TResNet.TResNetRegressProto()
